def luas_persegi(sisi): 
    luas = sisi * sisi 
    return luas 
# pemanggilan fungsi 
print ('Luas persegi: %d' % luas_persegi(6)) 