# Membuat fungsi dengan parameter 
def luas_segitiga(alas, tinggi): 
 luas = (alas * tinggi) / 2 
 print ('Luas segitiga: %f' % luas) 
# Pemanggilan fungsi 
luas_segitiga(4, 6)