# Membuat Fungsi 
def salam(): 
 print ('Hello, Selamat Pagi') 
## Pemanggilan Fungsi 
salam() 
salam() 
salam()