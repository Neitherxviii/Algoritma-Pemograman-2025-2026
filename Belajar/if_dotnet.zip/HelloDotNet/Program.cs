﻿class Program
{
  static void Main()
  {
    int umur = 18;
    if (umur < 18)
    {
      Console.WriteLine("Anda masih di bawah umur.");
    }
    else
    {
      Console.WriteLine("Anda sudah dewasa.");
    }
  }
}